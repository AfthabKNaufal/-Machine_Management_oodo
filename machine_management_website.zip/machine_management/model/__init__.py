# -*- coding: utf-8 -*-
from . import machine_management
from . import machine_management_type
from . import machine_transfer
from . import machine_tag
from . import machine_parts
from . import res_partner
from . import machine_service
